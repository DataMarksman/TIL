# 3. Python 문법

> **파이썬 문법 정리**
> 

[https://github.com/DataMarksman/TIL.git](https://github.com/DataMarksman/TIL.git)

---

## 0. 기본 Tip

- [**Excape sequence]**
    - 역슬래시(엔터 위의키: \  or ₩) 뒤에 특정 문자가 와서 특수한 기능을 하는 문자 조합
    - **예약 문자 리스트**
        
        ![Untitled](2%20Python%20%E1%84%8C%E1%85%A1%E1%84%85%E1%85%AD%E1%84%92%E1%85%A7%E1%86%BC%206d99a32c8c994afeb900704c18dcc09f/Untitled%203.png)
        
- **[예약어]**
    
    ```python
    import keyword
    print (keyword.kwlist)
    
    """ ['False', 'None', 'True', 'and', 'as', 'assert', 'async', 'await', 'break',
    'class', 'continue', 'def', 'del', 'elif', 'else', 'except', 'finally', 'for', 
    'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'nonlocal', 'not', 'or', 
    'pass', 'raise', 'return', 'try', 'while', 'with', 'yield'] """
    ```
    
- **[ 단축 평가 ]**
    - 결과가 확실한 경우 **두번째 값은 확인하지 않고 첫번째 값 반환**
    - And 연산에서 첫번째 값이 False인 경우 무조건 False → 첫번째 값 반환
    - or 연산에서 첫번째 값이 True인 경우 무조건 True → 첫번째 값 반환
    
    ```python
    print( 3 and 5 ) # 5
    print( 3 and 0 ) # 0
    print( 0 and 5 ) # 0
    print( 0 and 0 ) # 0
    
    print( 5 or 3 ) # 5
    print( 3 or 0 ) # 3
    print( 0 or 5 ) # 3
    print( 0 or 0 ) # 0
    ```
    
    ```python
    a = 5 and 4
    print(a) # 4
    
    b = 5 or 3
    print(b) # 5
    
    c = 0 or 5
    print(c) # 0
    
    d = 5 or 0
    print(d) # 5
    ```
    
- **[ input()과 map() ]**
    - input() : 사용자 데이터 입력
        - 숫자 입력 → 문자열로 저장됨 : 다시 숫자로 바꿔줘야 함
    - map(int, input().split()) : 여러 개의 데이터를 입력 받음
        - 해당 데이터들 각각을 int로 받음

## 1. 연산자

- 산술 연산자
    - 산술 연산자 리스트
        
        ```python
        + : 덧셈
        - : 뺄셈
        * : 곱셈
        / : 나눗셈
        // : 몫
        ** : 거듭제곱
        ```
        
    - 계산 우선순위는 일반 수학과 동일
    - 실수 연산시, 부동 소수점 [해결책]
        - 값 비교 과정에서 정수가 아닌 실수라면 주의할 것
        - 매우 작은 수 보다 작은지 확인하거나 math 모듈 활용
            
            ```python
            # 작은 수와 비교확인
            a = 3.2 - 3.1 
            b = 1.2 - 1.1
            print(abs(a - b) <= le-10) # True
            
            # math 모듈 활용
            import math
            print(math.isclose(a,b)) $ True
            ```
            
- **비교 연산자**
    - 수학의 등호 부등호와 동일 개념
    - 조건문에서 주로 사용, 값을 비교할 때 사용
    - 결과는 TRUE/FALSE 값을 리턴
    - 비교 연산자 예시
        
        ![Untitled](2%20Python%20%E1%84%8C%E1%85%A1%E1%84%85%E1%85%AD%E1%84%92%E1%85%A7%E1%86%BC%206d99a32c8c994afeb900704c18dcc09f/Untitled%204.png)
        
    - 비교 연산자 활용 예시
        
        ```python
        print(3 > 6) # False
        print(3.0 == 3) # True
        print(3 >= 0) # True
        print('3' != 3) # True str과 int는 다르니까!
        print('Hi' == 'hi') # False 대소문자 구분하니까!
        
        id(0) <> id(False)
        id(1) <> id(True)
        ```
        
- **논리 연산자**
    - 여러 조건이 있을 때
        - And : 모든 조건을 만족
        - Or : 여러 조건 중 하나만 만족
    - 일반적으로 비교연산자와 함께 사용
    - 논리 연산자 예시
        
        ![Untitled](2%20Python%20%E1%84%8C%E1%85%A1%E1%84%85%E1%85%AD%E1%84%92%E1%85%A7%E1%86%BC%206d99a32c8c994afeb900704c18dcc09f/Untitled%205.png)
        
        ```python
        print(True and True) # True
        print(True and False) # False
        print(False and True) # False
        print(False and False) # False
        
        print(True or True) # True
        print(True or False) # True
        print(False or True) # True
        print(False or False) # False
        ```
        
    - 논리 연산자 사용 예시
        - 22시가 지나고 졸리면 True, 졸리지 않다면 False인 코드를 만들어보자.
        
        ```python
        # 23시가 되었고, 잠이 오는 경우
        hour = 23
        status = 'sleepy'
        print(hour >= 22 and status == 'sleepy') # Ture
        
        # 23시가 되었지만, 잠이 안오는 경우
        hour = 23
        status = 'nice'
        print(hour >= 22 and status == 'sleepy') # False
        ```
        
    - 논리 연산자 주의할 점 / Not 연산자
        - Falsy: False는 아니지만, False로 취급되는 다양한 값
            - 0, 0.0 (), {}, [], None, “”(빈문자열)
        - 논리 연산자도 우선순위가 존재
            - not, and, or 순으로 우선순위가 높음
        - not 예시
            
            not은 오른쪽 값을 바로 평가함
            
            → not none #none이 F
            
            ```python
            print(not True) # False
            print(not 0) # True
            print(not 'hi') # False 문자열은 True 취급
            print(not True and False or not False) # True
            
            print(((not True) and False) or (not False)) # True
            ```
            
    - 논리 연산자의 단축 평가
        - 결과가 확실한 경우 **두번째 값은 확인하지 않고 첫번째 값 반환**
        - And 연산에서 첫번째 값이 False인 경우 무조건 False → 첫번째 값 반환
        - or 연산에서 첫번째 값이 True인 경우 무조건 True → 첫번째 값 반환
        - 0은 False, 1은 True
- 슬라이싱 연산자 (for 시퀀스형)
    - 슬라이싱을 이용하여 문자열을 나타낼 때,
    - 콜론을 기준으로 앞 인덱스에 해당하는 문자는 포함
    - 콜론을 기준으로 뒤 인덱스에 해당하는 문자는 미포함
    - 시퀀스를 슬라이싱 예시
        
        ```python
        # 리스트 ([1:4]에서 1은 포함 4는 미포함)
        print([1,2,3,5][1:4]) # [2,3,5]
        
        # 튜플
        print((1,2,3)[:2] # (1,2)
        
        # range
        print(range(10)[5:8]) # range(5,8)
        
        # 문자열
        print('abcd'[2:4]) #cd
        ```
        
        - 시퀀스를 k간격으로 슬라이싱 예시
            
            ```python
            # 리스트
            print([1,2,3,5][0:4:2]) # [1,3]
            
            # 튜플
            print((1,2,3)[0:4:2] # (1,3)
            
            # range
            print(range(10)[1:5:3]) # range(1,5,3)
            
            # 문자열
            print('abcdefg'[1:3:2]) #b
            ```
            
        - Quiz 문자열 슬라이싱 예제
            
            ```python
            s = 'abcdefghi'
            s[2:5]
            s[2:5:2]
            s[5:2:-1]
            s[:3]
            s[5:]
            
            s[::] # s[0:len(s):1]과 동일
            s[::-1] # s[-1:-(len(s)+1):-1]과 동일
            ```
            
    - 활용력
        - 라이트 카피
            - `a[:]` : ‘ : ‘ 라이트 카피, 전부 가져온다.
            - 특징: 아이디 값을 다르게 함.
        - 도려내기
            
            ```jsx
            # 도려내기
            a=[1,2,3,4,5,6]
            a[2:5] = []
            # a = [1,2,6]
            
            a[2:5] = [7,8,9]
            # a = [1,2,7,8,9]
            ```
            
        - 시각화
            
            ![Untitled](2%20Python%20%E1%84%8C%E1%85%A1%E1%84%85%E1%85%AD%E1%84%92%E1%85%A7%E1%86%BC%206d99a32c8c994afeb900704c18dcc09f/Untitled%208.png)
            
- 셋 연산자
    - ‘ | ‘ : 합집합
    - & : 교집합
    - - : 차집합
    - ^ : 대칭차집합 (합집합 - 교집합)
    - (여집합은 없음)
    - 코드 예시
        
        ```python
        A_set = {1,2,3,4]
        B_set = {1,2,3, "Hello",(1,2,3)}
        
        print(A_set | B_set) # {1,2,3,4,(1,2,3),'Hello'}
        print(A_set & B_set) # {1,2,3}
        print(B_set - A_set) # {(1,2,3), 'Hello'}
        print(B_set ^ A_set) # {'Hello', 4, (1,2,3)}
        ```
        
    

1. 제어문

[2. 제어문](3%20Python%20%E1%84%86%E1%85%AE%E1%86%AB%E1%84%87%E1%85%A5%E1%86%B8%20b73d2992ad214a6980dc87abcaaaf3a1/2%20%E1%84%8C%E1%85%A6%E1%84%8B%E1%85%A5%E1%84%86%E1%85%AE%E1%86%AB%2036f8e595bc0845989f2351fcdd7c04cc.md)

## 2. 제어문

> 파이썬은 기본적으로 위에서 아래로 차례대로 명령 수행
이를 제어하기 위한 조건문(선택적 실행)과 반복문(반복 실행)으로 구성
제어문은 순서도(flowchart)로 표현 가능
> 

### 2.1 조건문

> 조건문은 참/거짓을 판단할 수 있는 조건식과 함께 사용
> 
- 조건이 참인경우, 들여쓰기 되어있는 코드 블록 실행
- 이외의 경우 else 이후 들여쓰기 되어있는 코드 블록 실행

```python
if 조건 == True:
	명령문
else:
	명령문
```

1. 복수 조건문
    - 복수의 조건식을 활용할 경우 elif를 활용하여 표현
    
    ```python
    if 조건:
    	# code block
    elif 조건:
    	# code block
    elif 조건 :
    	# code block
    . . .
    else:
    		# code block
    ```
    
    ```python
    dust = 80
    if dust > 150:
    	print('매우 나쁨')
    elif dust > 80:
    	print('나쁨')
    elif dust > 30:
    	print('보통')
    else:
    	print('좋음')
    print ('미세먼지 확인 완료!')
    ```
    
2. 중첩 조건문
    - 조건문은 다른 조건문에 중첩되어 사용 될 수 있음
        - 들여쓰기에 유의해서 작성할 것
        
        ```python
        if 조건:
        	# code block
        	if 조건:
        		# code block
        else 조건 :
        	# code block
        ```
        
3. 조건 표현식
    - 조건 표현식이란,
        - 일반적으로 조건에 따라 값을 정할 때 활용
        - 삼항 연산자(Ternary Operator)로 부르기도 함
        - 요컨데 if를 한줄로 표현하는 방식
        
        ```python
        true인 경우의 값 if 조건 else false인 경우의 값
        # 이걸 왼참이라고 부르고       이걸 오거라고 부름
        ```
        
        ```python
        value = num if num >= 0 else -num
        # 절대값 표현식
        ```
        
        ```python
        num = int(input())
        if num % 2:
        	result = '홀수입니다.'
        else:
        	result = '짝수입니다.'
        print(result)
        # 위의 식과 동일함
        num = int(input())
        result = '홀수입니다.' if num % 2 else '짝수입니다.'
        print(result)
        ```
        

### 2.2 반복문

> 특정 조건을 만족할 때 까지 같은 동작을 반복하고 싶을 때 사용
> 
1. while 문
    - 종료 조건에 해당하는 코드를 통해 반복문을 종료시켜야함
2. for 문
    - 반복제어 가능한 객체를 모두 순회하면 종료 (별도의 종료조건 필요 없음)
3. 반복 제어
    - break, continue, for-else
        - break: 멈춰! for 문이랑 같이 써야해! if 랑 쓰지마!
            
            바로 위의 for 문 파괴. 
            
        - **for-else: 완주 축하 구문**
            
             for로 반복되는 구문을 전부 다 소진했을 때, else 뒤의 명령어 발동!