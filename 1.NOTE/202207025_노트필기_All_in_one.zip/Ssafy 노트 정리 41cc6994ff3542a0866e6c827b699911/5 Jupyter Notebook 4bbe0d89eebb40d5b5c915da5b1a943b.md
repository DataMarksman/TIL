# 5. Jupyter Notebook

> Decomposition(분해) : 나만의 함수를 만들어서, 나만의 기능 사용 가능!
Abstraction(추상화)
함수의 목적: **재사용성 + 가독성 + 생산성**
> 

---

## [ 0 ] 함수 인트로

### 0.1. Decomposition(분해)

### 0.2. Abstraction(추상화)

---

# [ 1 ] 함수 기초

> 내장 함수: 파이썬에 기본적으로 포함된 함수
회장 함수: import를 통해 외부라이브러리에서 제공되는 함수 
사용자 정의 함수: 사용자가 직접 만드는 함수
> 

## 1. 함수의 정의

- 특정한 기능을 하는 코드의 조각(묶음)
- 특정 코드를 매번 다시 작성하지 않고, 필요시에만 호출하여 간편히 사용

## 2. 함수의 기본 구조

```python
def function_name(parameter):
	# code blcok
	return returnig_value
```

- 선언과 호출
    - 함수의 선언은 def 키워드를 활용
    
    ```python
    def foo():               # foo() 파라미터(재료)가 없는 경우,
    	return True
    
    def add(x, y):           
    	return x + y
    ```
    
- 입력
- 문서화
- 문서화
- 범위
- 결과값

## 3. 함수의 결과값(output)

1. 값에 따른 함수의 종류
    - void function
        - 명시적인 return값이 없는 경우, None을 반환하고 종료
    - value returning function
        - 함수 실행 후, return문을 통해 값 반환
        - return을 하게 되면, 값 반환 후 함수가 바로 종료
    - print() vs return()
        - print 함수는 호출 될 때마다 값이 출력됨 (테스트용)
        - return 함수는 데이터 처리를 위해 사용
        - 먼저 print() 사용하고 return 써야한다. (서순 중요!)
        - return X → None / return O → 하나를 반환
            - 여러 개 반환 원할 시, Tuple 활용(혹은 리스트 같은 컨테이너 활용)
    

## 4. 함수의 입력(input)

> Parameter: 함수를 정의할 때, 함수 내부에서 사용되는 변수 (선언시, 파라미터)
Argument: 함수를 호출 할 때, 넣어주는 값 (호출시, 아규먼트)
> 

### 4.1.Argument

- 함수 호출시, 파라미터를 통해 전달 되는 값
- Argument는 소괄호 안에 할당 func_name(argument)
    - 필수 Argument: 반드시 전달 되어야 하는 Argument
    - 선택 Argument: 값을 전달하지 않아도 되는 경우는 기본값이 전달됨
1. Positional Arguments
    - 기본적으로 함수 호출시, Argument는 위치에 따라 함수 내에 전달됨
2. Keyword Arguments
    - 직접 변수의 이름으로 특정 Argument:를 전달할 수 있음
    - Keyword Argument 다음에 Positional Argument를 활용할 수 없음
        
        ```python
        add(x,y):
        return x + y
        add(x=2, y=5)
        add(2, y=5)
        add(x=2, 5) # 이건 작동 안함.한번 포지셔닝으로 작동하면, 계속 포지셔닝.
        ```
        
3. Default Argument Values
    - 기본 값을 지정하여 함수 호출 시 Argument 값을 설정하지 않도록 함
        - 정의된 것 보다 더 적은 개수의 Argument 들로 호출 될 수 있음
        
        ```python
        def add(x, y=0):
        	return x + y
        
        add (2 )
        
        def add (x, y=0):
        	x = 2
        	return x = 2, y = 0
        ```
        

### 4.2 *

1. 정해지지 않은 여러개의 Arguments 처리
    - 애스터리스크(언패킹 연산자) 덕분에 가능함 : *
    - 가변인자
        
        > 여러개의 Positional Argument를 하나의 필수 Parameter로 받아서 사용
        > 
        
        몇개의 Positional Argument를 받을지 모르는 함수를 정의할 때 유용
        
        ```python
        def add(*args):
        	for arg in args:
        			print(arg)
        ```
        
    - 패킹/언패킹
        - 가변인자를 이해하기 위해 필요
        - 패킹
            - 여러개의 데이터를 묶어서 변수에 할당 하는 것
        - 언패킹
            - 시퀀스 속 요소들을 여러개의 변수에 나누어 할당 하는 것
            - 언패킹시, 변수의 개수와 할당하고자 하는 요소의 개수가 동일해야함
            - 언패킹시, 왼쪽의 변수에 asterisk(*)를 붙이면, 할당하고 남은 요소를 리스트에 넣음
2. 가변 인자 ( *args )
3. 가변 키워드 인자 ( **kwargs )

### 4.3 Scope (파이썬의 범위)

> 함수는 코드 내부에 local scope를 생성하며, 그외의 공간인 global scope로 구분
> 
- scope
    - global scope: 코드 어디에서는 참조할 수 있는 공간
    - local scope: 함수가 만든 scope. 함수 내부에서만 참조 가능
- variable(변수)
    - global variable: global scope에 정의된 변수
    - local variable: local scope에 정의된 변수
- lifecycle (변수 수명 주기)
    
    > 변수는 각자의 수명주기가 존재
    > 
    - built-in scope (영원히…)
        - 파이썬이 실행된 이후부터 영원히 유지
    - global scope (코드 창이 열려있다면..)
        - 모듈이 호출된 시점 이후 혹은 인터프리터가 끝날 때 까지 유지
    - local scope (함수가 돌아가는 동안.)
        - 함수가 호출 될 때 생성, 함수가 종료될 때 까지 유지
- 이름 검색 규칙 (Name Resolution)
    - 파이썬에서 사용되는 이름
    - LEGB RULE
        - Local Scope: 지역범위(현재 작업 중인 범위)
        - Enclosed scope: 지역범위 한 단계 위 범위
        - Global scope: 최상단에 위치한 범위
        - Built-in scope: 모든 것을 담고 있는 범위